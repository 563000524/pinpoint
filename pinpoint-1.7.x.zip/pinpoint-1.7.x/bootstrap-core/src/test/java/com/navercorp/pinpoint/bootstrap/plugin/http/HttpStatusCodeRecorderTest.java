/*
 * Copyright 2017 NAVER Corp.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.navercorp.pinpoint.bootstrap.plugin.http;

import com.navercorp.pinpoint.bootstrap.context.SpanRecorder;
import org.junit.Test;

import java.util.Arrays;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;

/**
 * @author jaehong.kim
 */
public class HttpStatusCodeRecorderTest {

    @Test
    public void record() throws Exception {
        final SpanRecorder spanRecorder = mock(SpanRecorder.class);

        HttpStatusCodeRecorder recorder = new HttpStatusCodeRecorder(Arrays.asList("5xx"));

        recorder.record(spanRecorder, 500);
        recorder.record(spanRecorder, 200);
        recorder.record(spanRecorder, 404);

        // illegal argument.
        recorder.record(null, 500);
        recorder.record(spanRecorder, 0);
        recorder.record(spanRecorder, -1);
        recorder.record(spanRecorder, 999);
    }

    @Test
    public void isFailed() throws Exception {
        HttpStatusCodeRecorder recorder = new HttpStatusCodeRecorder(Arrays.asList("5xx", "401", "402"));

        assertTrue(recorder.isFailed(500));
        assertTrue(recorder.isFailed(501));
        assertTrue(recorder.isFailed(401));
        assertTrue(recorder.isFailed(402));

        assertFalse(recorder.isFailed(100));
        assertFalse(recorder.isFailed(200));
        assertFalse(recorder.isFailed(201));
        assertFalse(recorder.isFailed(300));
        assertFalse(recorder.isFailed(400));
        assertFalse(recorder.isFailed(404));

        // out of range
        assertFalse(recorder.isFailed(0));
        assertFalse(recorder.isFailed(999));
        assertFalse(recorder.isFailed(-1));
        assertFalse(recorder.isFailed(99));
    }
}