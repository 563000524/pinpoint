namespace java com.navercorp.pinpoint.plugin.thrift.dto

service EchoService
{
    string echo(1:string message)
}